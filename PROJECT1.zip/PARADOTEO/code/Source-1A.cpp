﻿//********************************
//Αυτό το αρχείο θα το χρησιμοποιήσετε
// για να υλοποιήσετε την άσκηση 1Α της OpenGL
//
//ΑΜ: 5398                        Όνομα: Christodoulos Apsiotis
//ΑΜ: 5401                        Όνομα: Charalampos Kounnapis

//*********************************

#include <stdio.h>
#include <stdlib.h>
#include <ctime>
#include <cstdlib>

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <windows.h>

// Include GLEW
#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>
GLFWwindow* window;

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;
using namespace std;

//******************
// Η LoadShaders είναι black box για σας - αγνοήστε την συνάρτηση Loadshaders

GLuint LoadShaders(const char* vertex_file_path, const char* fragment_file_path) {

	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read the Vertex Shader code from the file
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if (VertexShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << VertexShaderStream.rdbuf();
		VertexShaderCode = sstr.str();
		VertexShaderStream.close();
	}
	else {
		printf("Impossible to open %s. Are you in the right directory ? Don't forget to read the FAQ !\n", vertex_file_path);
		getchar();
		return 0;
	}

	// Read the Fragment Shader code from the file
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if (FragmentShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << FragmentShaderStream.rdbuf();
		FragmentShaderCode = sstr.str();
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;


	// Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);

	// Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> VertexShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
		printf("%s\n", &VertexShaderErrorMessage[0]);
	}



	// Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);

	// Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> FragmentShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
		printf("%s\n", &FragmentShaderErrorMessage[0]);
	}



	// Link the program
	printf("Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> ProgramErrorMessage(InfoLogLength + 1);
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
		printf("%s\n", &ProgramErrorMessage[0]);
	}


	glDetachShader(ProgramID, VertexShaderID);
	glDetachShader(ProgramID, FragmentShaderID);

	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

void addSquare(vector<GLfloat>& vertices, float x, float y, float n) {
	//proto trigono
	vertices.insert(vertices.end(), {
		x, y, 0.0f,
		x, y - n, 0.0f,
		x + n, y, 0.0f });
	//deftero rtigono
	vertices.insert(vertices.end(), {
		x, y - n, 0.0f,
		x + n,y - n, 0.0f,
		x + n, y, 0.0f });
}

//dimiourgia ton tessaron montelon
vector<GLfloat> createModel(int type, float x, float y) {
	vector<GLfloat> vertices;
	float n = 1.0f;
	//1o montelo
	addSquare(vertices, x, y, n);

	//2o montelo 
	if (type == 1) {
		addSquare(vertices, x + n, y, n);
	}

	//3o montelo 
	else if (type == 2) {
		addSquare(vertices, x, y - n, n);
		addSquare(vertices, x, y - 2 * n, n);

	}

	//4o montelo
	else if (type == 3) {
		addSquare(vertices, x + n, y, n);
		addSquare(vertices, x, y - n, n);
	}
	return vertices;
}

//elechos gia epikalipsi 2 montelon
bool overlap(const vector<GLfloat>& newModel, const vector<vector<GLfloat>>& models) {
	for (const auto& model : models) {
		for (int i = 0; i < newModel.size(); i += 18) {
			for (int j = 0; j < model.size(); j += 18) {
				if (newModel[i] == model[j] && newModel[i + 1] == model[j + 1]) {
					return true;
				}
			}
		}
	}
	return false;
}
/*******************************************************************/
int main(void)
{
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	// Allazoume to megethos tou parathirou apo 750x750 se 900x900
	window = glfwCreateWindow(900, 900, "Εργασια 1Α - 5398 - 5401", NULL, NULL);

	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

	// blue background
	// Vazoume skouro mple chroma sto kouti
	glClearColor(0.05f, 0.05f, 0.45f, 1.0f);

	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	//***********************************************
	// Οι shaders σας είναι οι 
	// ProjectVertexShader.vertexshader
	// ProjectFragmentShader.fragmentshader

	GLuint programID = LoadShaders("ProjectVertexShader.vertexshader", "ProjectFragmentShader.fragmentshader");

	///////////////////////////////////////////////////////////////////////////////////////	
	/**Το παρακάτω το αγνοείτε - είναι τοποθέτηση κάμερας ***/
	GLuint MatrixID = glGetUniformLocation(programID, "MVP");

	glm::mat4 Projection = glm::perspective(glm::radians(45.0f), 4.0f / 4.0f, 0.1f, 100.0f);
	// Camera matrix
	glm::mat4 View = glm::lookAt(
		glm::vec3(0, 0, 30), // Camera  in World Space
		glm::vec3(0, 0, 0), // and looks at the origin
		glm::vec3(0, 1, 0)  // 
	);

	glm::mat4 Model = glm::mat4(1.0f);
	glm::mat4 MVP = Projection * View * Model;
	///////////////////////////////////////////////////////////////////////////////////////
	//**************************************************
	/// Για βοήθεια το πρόγραμμα αναπαριστά δυο τυχαία τρίγωνα - εσείς θα πρέπει να βάλετε κορυφές κατάλληλες 
	//  για τα δικό σας τρίγωνα.
	//Στην άσκηση αυτή δουλεύετε στις 2 διαστάσεις x,y οπότε η z συνιστώσα θα ειναι πάντα 0.0f
	// ή θα την παραλείψετε.
	/////////////////////////////////////////////////////////////////////////////////////////

	// oloes oi korifes
	vector<GLfloat> shape;

	//apothikevi mechri 3 montela
	vector<vector<GLfloat>> models;

	bool previousS = false;
	bool previousD = false;

	//tichaioi arithmoi
	srand(static_cast<unsigned int>(time(0)));

	GLuint vbuffer;
	glGenBuffers(1, &vbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vbuffer);

	do {
		//elechos gia to pliktro S
		bool currentS = (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS);

		//dimiourgi mechri 3 montela
		if (currentS && !previousS && models.size() < 3) {
			//tichea epilogi montelou
			int modelType = rand() % 4;
			vector<GLfloat> newModel;
			//to do ektelei dimiourgia montelou se tichea thesi
			do {
				//tchees sintetagmenes
				float x = rand() % 19 - 9;
				float y = rand() % 20 - 8;

				//dimioiurgia tou montelou 
				newModel = createModel(modelType, x, y);
			} while (overlap(newModel, models));//eno to while elechi an eiparchi epikalipsi
			//apothikevei to montelo
			models.push_back(newModel);
		}

		//neo montelo otan patiete to s kathe fora 
		previousS = currentS;

		//elechos gia to pliktro d
		bool currentD = (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS);

		//diagrafi tou palioterou montelou
		if (currentD && !previousD && !models.empty()) {
			models.erase(models.begin());
		}
		previousD = currentD;

		//to parathiro xekina adio
		shape.clear();

		for (const auto& model : models) {
			shape.insert(shape.end(), model.begin(), model.end());
		}
		// Clear the screen 
		glClear(GL_COLOR_BUFFER_BIT);

		// Use our shader
		glUseProgram(programID);
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);  /// Αυτό αφορά την κάμερα  - το αγνοείτε


		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vbuffer);
		//metafora korifon
		glBufferData(GL_ARRAY_BUFFER, shape.size() * sizeof(GLfloat), shape.empty() ? nullptr : shape.data(), GL_DYNAMIC_DRAW);
		glVertexAttribPointer(
			0,                  // attribute 0, must match the layout in the shader.
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// Draw the triangle !
		// Valame tin pio kato grammi kodika se scholia giati sto ii) thelei na anigi ena adio mple 
		// parathiro
		//glDrawArrays(GL_TRIANGLES, 0, 3 * 2); // 3 vertices for each triangle -> 6 vertices total for 2 triangles
		//tin antikathistoume me tin pio kato etsi oste na ginete schediasi olon ton 
		//korifon tou montelou
		glDrawArrays(GL_TRIANGLES, 0, static_cast<GLsizei>(shape.size() / 3));

		glDisableVertexAttribArray(0);



		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();

	} while (glfwGetKey(window, GLFW_KEY_Q) != GLFW_PRESS && glfwWindowShouldClose(window) == 0);


	// Cleanup VBO
	glDeleteBuffers(1, &vbuffer);
	glDeleteVertexArrays(1, &VertexArrayID);
	glDeleteProgram(programID);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}

